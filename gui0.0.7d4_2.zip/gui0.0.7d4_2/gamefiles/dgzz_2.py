#添加库
import pgzrun
import os
import sys
import time
#窗口
TITLE = '帝国战争0.0.7d4'#项目名
WIDTH = 854 #设置长位854
HEIGHT = 480 #设置宽为480
#变量0
timer = 0
mut = 0
fcf1 = 0
nt = 0
nt2 = 0
nt3 = 0
nt4 = 0
sj = 0
wjgj2 = 0
hp1 = 7
tl = 3
day = 0
hptl = 0
rl1 = 0
nt1 = 0
#变量1
map1 = 0
miba = 0
zz = 0
wood = 0
rock = 0
mf = 0
guwu = 0
water = 0
sm1 = 0
kush = 0
kudi = 0
#图片
ct = Actor('kong',(397,465))
ct2 = Actor('kong',(447,465))
wjct = Actor('kong',(427,240))
wpl1 = Actor('wpl_2',(397,465))
wpl2 = Actor('wpl_2',(447,465))
ys = Actor('ys_2',(820,50))
fz = Actor('fz',(427,240))
tree = Actor('tree_2',(267,60))
tree2 = Actor('tree_2',(127,70))
tree3 = Actor('tree_2',(217,80))
ren = Actor('ren_1',(427,240)) # 设置角色ren的位置
cc = Actor('cc_1',(427,240)) # 设置图片cc的位置
fcf = Actor('kong',(410,190))
sm = Actor('sj_sm_3',(145,10))
mg = Actor('cl_mg',(410,190))
he = Actor('he_1',(780,465))
he2 = Actor('he_1',(810,465))
he3 = Actor('he_1',(840,465))
he4 = Actor('he_6',(780,435))
he5 = Actor('he_6',(810,435))
he6 = Actor('he_6',(840,435))
gd = Actor('kong',(0,0))
gd2 = Actor('kong',(0,0))
gd3 = Actor('kong',(0,0))
gd4 = Actor('kong',(0,0))
tz1 = Actor('kong',(820,40))
hp = Actor('sj_sm_3',(145,30))
rl = Actor('kong',(360,210))
#自定义
#显示
def draw():
    if sj == 0 or timer <= 30:
        screen.blit('bj3', pos=[0, 0])#设置背景
        cc.image = 'cc_1'
        fz.image = 'fz'
    if sj == 1 or timer > 30 and timer <= 60:
        screen.blit('bj3_2', pos=[0, 0])#设置背景
    if sj == 2 or timer > 60 and timer <= 90:
        screen.blit('bj3_3', pos=[0, 0])#设置背景
        cc.image = 'cc_2'
        fz.image = 'fz_2'
        he.image = 'he_1'
        he2.image = 'he_1'
        he3.image = 'he_1'
        he4.image = 'he_6'
        he5.image = 'he_6'
        he6.image = 'he_6'
    cc.draw()
    fz.draw()
    ys.draw()
    fcf.draw()
    he.draw()
    he2.draw()
    he3.draw()
    he4.draw()
    he5.draw()
    he6.draw()
    gd.draw()
    gd2.draw()
    gd3.draw()
    gd4.draw()
    tz1.draw()
    tree.draw()
    tree2.draw()
    tree3.draw()
    rl.draw()
    ren.draw()
    wpl1.draw()
    wpl2.draw()
    wjct.draw()
    ct.draw()
    ct2.draw()
    sm.draw()#体力
    hp.draw()#生命
    screen.draw.text(f'天数:{day}',center=[427,10],fontsize = 20, color = 'black',fontname='simsun')
    screen.draw.text('体力:',center=[25,10],fontsize = 20, color = 'black',fontname='simsun')#显示体力#{timer}
    screen.draw.text('生命:', center=[25, 30], fontsize=20, color='black', fontname='simsun')#显示生命
    screen.draw.text('e背包合成 r挖掘 h说明',center=[745,10],fontsize = 20, color = 'black',fontname='simsun')#显示帮助
#主要内容
#按键1
def on_key_down(key):
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    global sj
    global wjgj2
    global tl
    global hp
    global day
    global hptl
    global rl1
    global nt1
    #变量1
    global map1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    global kush
    global kudi
    if rock >= 200 and wood >= 200 and fcf1 == 1 and map1 == 0:
       map1 = 1
       print('您已获得地图')
    if rock >= 200 and wood >= 200 and fcf1 == 1 and map1 == 1:
       if key == keys.Q:
          os.system("python dgzz_2_map.py")#打开地图
    if rock >= 100:
       tz1.image = 'tz_1'
    if ren.colliderect(tz1) and tz1.image == 'tz_1':
       if key == keys.R:
          os.system("python dgzz_2_kd1.py")#爬梯子进入矿洞
    if key == keys.R:
        if ren.colliderect(cc) or ren.colliderect(gd) or ren.colliderect(gd2) or ren.colliderect(gd3) or ren.colliderect(gd4) or ren.colliderect(tree) or ren.colliderect(tree2) or ren.colliderect(tree3) or ren.colliderect(ys):
            print('无法获得种子')
        else:
            zz += 1
            print('种子+1')
    if tree.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree.image = 'kong'
            tree.x = 0
            tree.y = 0
            sm1 += 1
            print('木材+1')
            print('树苗+1')
    if tree2.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree2.x = 0
            tree2.y = 0
            tree2.image = 'kong'
            sm1 += 1
            print('木材+1')
            print('树苗+1')
    if tree3.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree3.x = 0
            tree3.y = 0
            tree3.image = 'kong'
            sm1 += 1            
            print('木材+1')
            print('树苗+1')
    if ren.colliderect(tree) and tree.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree.image = 'sz_1'
            print('木材+3')
    if ren.colliderect(tree2) and tree2.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree2.image = 'sz_1'
            print('木材+3')
    if ren.colliderect(tree3) and tree3.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree3.image = 'sz_1'
            print('木材+3')
    if tree.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            tree.x = ren.x
            tree.y = ren.y
            print('播种成功 树苗-1')
            sm1 -= 1
            print('树苗:',sm1)
            tree.image = 'sm_1'
    if tree2.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            tree2.x = ren.x
            tree2.y = ren.y
            print('播种成功 树苗-1')
            sm1 -= 1
            print('树苗:',sm1)
            tree2.image = 'sm_1'
    if tree3.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            print('播种成功 树苗-1')
            tree3.x = ren.x
            tree3.y = ren.y
            sm1 -= 1
            print('目前树苗:',sm1)
            tree3.image = 'sm_1'
    if ren.colliderect(tree) and tree.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree.image = 'tree_2'
    if ren.colliderect(tree2) and tree2.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree2.image = 'tree_2'
    if ren.colliderect(tree3) and tree3.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree3.image = 'tree_2'
    if key == keys.E:
        print('木材:',wood)
        print('岩石:',rock)
        print('谷物:',guwu)
        print('面粉:',mf)
        print('水:',water)
        print('种子:',zz)
        print('树苗:',sm1)
        print('面包:', miba)
        print('矿石:', kush)
        print('矿锭:', kudi)
        print('合成表：20石头+5木头=1石锄头 25木头=1木锄头 没有,合成一次 自动合成')
    if key == keys.H:
        print('帮助：种田，建房请去城池中心 树苗只能砍一个才能种一个,不能多砍才种,播种树苗需要浇水 吃东西回血')
        print('帮助：木头200 石头200 并且有了风车房后 会获得地图')        
        print('键位: WSAD上下左右移动 E打开背包或自动合成 R交互键（打开，交互，挖掘）G读取存档 C存档 数字1，2 切换物品栏 H帮助 F种树苗 V吃东西 `自杀 Q打开地图')
        print('特定键位: 风车房F制作面粉B制作面包 河中M+1合成木桶')
    if key == keys.V:
        if miba >= 1 and tl >= 3:
            if sm.image == 'sj_sm_4':
                miba -= 1
                print('已使用食物')
                tl -= 1
            if sm.image == 'sj_sm_5':
                miba -= 1
                print('已使用食物')
                tl -= 1
            if sm.image == 'sj_sm_6':
                miba -= 1
                print('已使用食物')
                tl -= 1
    if key == keys.BACKQUOTE:
        if sm.image == 'sj_sm_3':
            tl += 1
        if sm.image == 'sj_sm_4':
            tl += 1
        if sm.image == 'sj_sm_5':
            tl += 1
        if sm.image == 'sj_sm_6':
            tl += 1
    if tl == 3:
        sm.image = 'sj_sm_3'
    if tl == 4:
        sm.image = 'sj_sm_4'
    if tl == 5:
        sm.image = 'sj_sm_5'
    if tl == 6:
        sm.image = 'sj_sm_6'
    if tl == 7:
        sm.image = 'sj_sm_7'
#------------------------------------
    if hp1 == 7:
        hp.image = 'sj_sm_3'
    if hp1 == 6:
        hp.image = 'sj_sm_4'
    if hp1 == 5:
        hp.image = 'sj_sm_5'
    if hp1 == 4:
        hp.image = 'sj_sm_6'
    if hp1 == 3:
        hp.image = 'sj_sm_7'
    if ren.colliderect(fz):
        if nt1 == 0:
            if key == keys.R:
                print('是否建造农田 按F同意(水边，需要锄)')
            if key == keys.F:
                if nt1 == 1 or (wjct.image == 'gj_ct_1' and zz >= 17) or (wjct.image == 'gj_sc_1' and zz >= 17):
                    nt1 = 1
                    nt = 1
                    nt2 = 1
                    nt3 = 1
                    nt4 = 1
                    gd.x = 755
                    gd.y = 460
                    gd.image = 'gd_1'
                    gd2.x = 755
                    gd2.y = 475
                    gd2.image = 'gd_1'
                    gd3.x = 755
                    gd3.y = 430
                    gd3.image = 'gd_1'
                    gd4.x = 755
                    gd4.y = 445
                    gd4.image = 'gd_1'
                    zz -= 16
                    print('完成')
                    print('种子:',zz)
                else:
                    print('没有锄或者种子不够（种子>16）')
        if fcf1 == 0 and nt1 == 1:
            if key == keys.R:
                print('是否建造风车房 按F同意(木头 石头各50)')
            if key == keys.F:
                if fcf1 == 1 or rock >= 50 and wood >= 50:
                    fcf1 = 1
                    print('建造完毕')
                    rock -= 50
                    wood -= 50
                    print('目前木材:',wood)
                    print('目前岩石:',rock)
                    fcf.image = 'jz_fc_1'
                else:
                    print('抱歉，您的材料不够')
                    print('目前木材:',wood)
                    print('目前岩石:',rock)
        if fcf1 == 1:
           fcf.image = 'jz_fc_1'
        if rl1 == 1:
           rl.image = 'jz_rl_1'
        if fcf1 == 1 and nt1 == 1 and rl1 != 1:
           if key == keys.R:
               if rl1 == 0:
                   print('是否建造熔炉 按F同意(石头100)')
           if key == keys.F:
               if rl1 == 0 and rock >= 100:
                   rl1 = 1
                   rock -= 100
                   rl.image = 'jz_rl_1'
                   fz.image = 'kong'
                   print('目前岩石:',rock)
               if rl1 == 0 and rock <= 100:
                   print('抱歉，您的材料不够')
                   print('目前岩石:',rock)
    if nt1 == 1:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_1'
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_1'
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_1'
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_1'
    if nt == 2:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_2'
    if nt2 == 2:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_2'
    if nt3 == 2:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_2'
    if nt4 == 2:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_2'
    #3
    if nt == 3:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_3'
    if nt2 == 3:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_3'
    if nt3 == 3:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_3'
    if nt4 == 3:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_3'
    #4
    if nt == 4:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_4'
    if nt2 == 4:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_4'
    if nt3 == 4:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_4'
    if nt4 == 4:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_4'
    #分
    if gd.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd):
                if nt == 1:
                    nt = 2
                    gd.image = 'gd_2'
                    zz -= 4
    if gd2.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd2):
                if nt == 1:
                    nt2 = 2
                    gd2.image = 'gd_2'
                    zz -= 4
    if gd3.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd3):
                if nt == 1:
                    nt3 = 2
                    gd3.image = 'gd_2'
                    zz -= 4
    if gd4.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd4):
                if nt == 1:
                    nt4 = 2
                    gd4.image = 'gd_2'
                    zz -= 4
    if gd.image == 'gd_2':
       nt += 1
    if gd2.image == 'gd_2':
       nt2 += 1
    if gd3.image == 'gd_2':
       nt3 += 1
    if gd4.image == 'gd_2':
       nt4 += 1
    if gd.image == 'gd_3':
       nt += 1
    if gd2.image == 'gd_3':
       nt2 += 1
    if gd3.image == 'gd_3':
       nt3 += 1
    if gd4.image == 'gd_3':
       nt4 += 1
    if ren.colliderect(gd):
        if gd.image == 'gd_4' or nt == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd.image = 'gd_2'
                nt = 2
    if ren.colliderect(gd2):
        if gd2.image == 'gd_4' or nt2 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd2.image = 'gd_2'
                nt2 = 2
    if ren.colliderect(gd3):
        if gd3.image == 'gd_4' or nt3 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd3.image = 'gd_2'
                nt3 = 2
    if ren.colliderect(gd4):
        if gd4.image == 'gd_4' or nt4 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd4.image = 'gd_2'
                nt4 = 2
    if ren.colliderect(fcf) and fcf1 == 1:
        if key == keys.R:
            print('按F制作面粉(按一次-5谷物+1面粉) 按B制作面包（一次一个，-10面粉）')
        if key == keys.F:
            if guwu >= 5:
                print('面粉+1')
                print('谷物-1')
                guwu -= 5
                mf += 1
            else:
                print('抱歉，您的材料不够')
                print('目前谷物:',guwu)
        if key == keys.B:
            if mf >= 10:
                print('面包+1')
                print('面粉-10')
                miba += 1
                mf -= 10
            else:
                print('抱歉，您的材料不够')
                print('目前面粉:',mf)
    if fcf1 == 1:
        fcf.image = 'jz_fc_1'
    if ren.colliderect(ys):
        if key == keys.R:
            rock += 1
            print('岩石+1')
        if wjct.image == 'gj_sc_1':
            if key == keys.R:
                rock += 2
                print('岩石+2')
        if wjct.image == 'gj_ct_1':
            if key == keys.R:
                rock += 1
                print('岩石+1')
    if ren.colliderect(rl) and rl1 == 1:
        if key == keys.R:
            print('是否熔炼矿物? (按F熔炼 需矿物木头)')
        if key == keys.F:
            if kush > 0 and wood > 0:
                kush -= 1
                wood -= 1
                kudi += 1
                print('矿锭+1')
                print('矿石-1')
                print('木头-1')
            else:
                print('抱歉，您的材料不够')
                print('矿石',kush)
                print('木头',wood)
    if key == keys.C:
        with open('cd.txt', 'w') as f:
            print(wood, file=f)
            print(rock, file=f)
            print(guwu, file=f)
            print(mf, file=f)
            print(mut, file=f)
            print(water, file=f)
            print(zz, file=f)
            print(nt, file=f)
            print(nt2, file=f)
            print(nt3, file=f)
            print(nt4, file=f)
            print(fcf1, file=f)
            print(miba, file=f)
            print(sm1, file=f)
            print(sj, file=f)
            print(map1, file=f)
            print(kush, file=f)
            print(day, file=f)
            print(wjgj2, file=f)
            print(kudi, file=f)
            print(rl1, file=f)
            print(nt1, file=f)
    if key == keys.G:
        f = open('cd.txt')
        score = f.read().split()
        wood = int(score[0])
        rock = int(score[1])
        guwu = int(score[2])
        mf = int(score[3])
        mut = int(score[4])
        water = int(score[5])
        zz = int(score[6])
        nt = int(score[7])
        nt2 = int(score[8])
        nt3 = int(score[9])
        nt4 = int(score[10])
        fcf1 = int(score[11])
        miba = int(score[12])
        sm1 = int(score[13])
        sj = int(score[14])
        map1 = int(score[15])
        kush = int(score[16])
        day = int(score[17])
        wjgj2 = int(score[18])
        kudi = int(score[19])
        rl1 = int(score[20])
        nt1 = int(score[21])
    if ren.colliderect(he):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 1
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he2):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 3
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he3):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 3
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he4):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 1
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he5):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 9
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he6):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 9
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if key == keys.L:
       print('准确时间:',timer)
#按键2
def update(dt):
    #变量0
    global timer
    timer += dt
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    global sj
    global wjgj2
    global tl
    global hp1
    global day
    global hptl
    global rl1
    global nt1
    #变量1
    global map1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    global kush
    global kudi
    if keyboard.M:
        if keyboard.K_1:
            if mut == 0:
                if wood >= 10:
                    mut = 1
                    print('木桶+1')
                    wood -= 10
                    print('木头-10')
                else:
                    print('您的材料不够')
                    print('木头:',wood)
            else:
                print('已有木桶')
    if keyboard.K_1:
        wpl1.image = 'wpl_1'
        wpl2.image = 'wpl_2'
        if ct.image == 'gj_sc_1':
            wjct.image = 'gj_sc_1'
            wjgj2 = 2
        if ct.image == 'gj_ct_1':
            wjct.image = 'gj_ct_1'
            wjgj2 = 1
        if ct.image == 'gj_wq_1':
            wjct.image = 'gj_wq_1'
            wjgj2 = 3
        if ct.image == 'kong':
            wjct.image = 'kong'
            wjgj2 = 0
    if keyboard.K_2:
        wpl2.image = 'wpl_1'
        wpl1.image = 'wpl_2'
        if ct2.image == 'gj_sc_1':
            wjct.image = 'gj_sc_1'
            wjgj2 = 2
        if ct2.image == 'gj_ct_1':
            wjct.image = 'gj_ct_1'
            wjgj2 = 1
        if ct2.image == 'gj_wq_1':
            wjct.image = 'gj_wq_1'
            wjgj2 = 3
        if ct2.image == 'kong':
            wjct.image = 'kong'
            wjgj2 = 0
    if keyboard.D:
        ren.x += 1
        wjct.x += 1
        ren.image = 'ren_2'
    if keyboard.D and keyboard.LCTRL:
        ren.x += 2
        wjct.x += 2
        ren.image = 'ren_2'
    if keyboard.D == False:
        ren.image = 'ren_1'
    if keyboard.A == True:
        wjct.x -= 1
        ren.image = 'ren_3'
        ren.x -= 1
    if keyboard.A == False:
        ren.image = 'ren_1'
    if keyboard.A and keyboard.LCTRL:
        wjct.x -= 2
        ren.x -= 2
        ren.image = 'ren_2'
    if keyboard.S == True:
        ren.image = 'ren_2'
        ren.y += 1
        wjct.y += 1
    if keyboard.S == False:
        ren.image = 'ren_1'
    if keyboard.S and keyboard.LCTRL:
        ren.y += 2
        wjct.y += 2
        ren.image = 'ren_2'
    if keyboard.W == True:
        ren.image = 'ren_2'
        ren.y -= 1
        wjct.y -= 1
    if keyboard.W:
        ren.image = 'ren_1'
    if keyboard.W and keyboard.LCTRL:
        ren.y -= 2
        wjct.y -= 2
        ren.image = 'ren_2'
    if ren.x == 0 or ren.x == 854 or ren.y == 0 or ren.y == 480:
        print('触碰边界线')
    if wjct.image == 'kong':
        if wood >= 5 and rock == 20 and wjgj2 != 2:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
            wood -= 5
            rock -= 20
            wjgj2 = 2
        if wjgj2 == 2:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
        if wood >= 25 or wjgj2 == 1 and wjgj2 != 1 and wjgj2 != 2:
            wjct.image = 'gj_ct_1'
            ct.image = 'gj_ct_1'
            wood -= 25
            wjgj2 = 1
        if wjgj2 == 1:
            wjct.image = 'gj_ct_1'
            ct.image = 'gj_ct_1'
        if wood >= 5 and kudi >= 20:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
            wood -= 5
            kudi -= 20
        if wjgj2 == 3:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
    if wjct.image == 'gj_ct_1':
        if wood >= 5 and rock == 20 and wjgj2 != 2:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
            wood -= 5
            rock -= 20
            wjgj2 = 2
        if wjgj2 == 2:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
        if wood >= 5 and kudi >= 20:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
            ct2.image = 'gj_ct_1'
            wood -= 5
            kudi -= 20
        if wjgj2 == 3:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
            ct2.image = 'gj_ct_1'
    if wjct.image == 'gj_sc_1':
        if wood >= 5 and kudi >= 20:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
            ct2.image = 'gj_sc_1'
            wood -= 5
            kudi -= 20
        if wjgj2 == 3:
            wjct.image = 'gj_wq_1'
            ct.image = 'gj_wq_1'
            ct2.image = 'gj_sc_1'
    if sm.image == 'sj_sm_7':
        hp1 -= 1
        sm.image = 'sj_sm_3'
        tl = 3
    if hp.image == 'sj_sm_7':
        input('您已死亡，请按回车退出')
        sys.exit(0)
    if timer <= 30 and timer >= 0:
       sj = 0
    if timer <= 60 and timer >= 30:
       sj = 1
    if timer <= 90 and timer >= 60:
       sj = 2
    if timer >= 91:
       timer = 0
       tl += 1
       day += 1
       if hp1 != 7:
           hp1 += 1
pgzrun.go()# 运行pygame zero

