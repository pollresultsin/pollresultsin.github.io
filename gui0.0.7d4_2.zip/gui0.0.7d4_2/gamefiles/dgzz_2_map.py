import pgzrun# 导入pygame zero

TITLE = '帝国战争0.0.7d4_地图'#项目名
WIDTH = 256 #设置长位128
HEIGHT = 256 #设置宽为128

def draw():
    screen.blit('dt_1', pos=[0, 0])#设置背景
pgzrun.go()# 运行pygame zero

