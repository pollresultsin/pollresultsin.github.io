import pgzrun# 导入pygame zero
import os
import sys
#sys.exit(0)

TITLE = '帝国战争0.0.7d4'#项目名
WIDTH = 854 #设置长位854
HEIGHT = 480 #设置宽为480
#变量0
timer = 0
mut = 0
fcf1 = 0
nt = 0
nt2 = 0
nt3 = 0
nt4 = 0
sj = 0
wjgj2 = 0
hp1 = 7
tl = 3
day = 0
hptl = 0
rl1 = 0
nt1 = 0
#变量1
map1 = 0
miba = 0
zz = 0
wood = 0
rock = 0
mf = 0
guwu = 0
water = 0
sm1 = 0
kush = 0
kudi = 0
bc100 = 0

ren = Actor('ren_4',(427,240)) # 设置图片ren的位置
tz1 = Actor('tz_2',(140,60)) # 设置图片梯子的位置
ct = Actor('kong',(397,465))
ct2 = Actor('kong',(447,465))
wjct = Actor('kong',(427,240))
wpl1 = Actor('wpl_2',(397,465))
wpl2 = Actor('wpl_2',(447,465))

def draw():
    screen.draw.text('生命:',center=[25,10],fontsize = 20, color = 'black',fontname='simsun')#显示生命
    screen.blit('bj_kd_1', pos=[0, 0])#设置背景
    tz1.draw()
    ren.draw()
    wpl1.draw()
    wpl2.draw()
    wjct.draw()
    ct.draw()
    ct2.draw()
def on_key_down(key):
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    global sj
    global wjgj2
    global tl
    global hp
    global day
    global hptl
    global rl1
    global nt1
    #变量1
    global map1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    global kush
    global kudi
    global bc100
    if bc100 == 0:
        f = open('cd.txt')
        score = f.read().split()
        wood = int(score[0])
        rock = int(score[1])
        guwu = int(score[2])
        mf = int(score[3])
        mut = int(score[4])
        water = int(score[5])
        zz = int(score[6])
        nt = int(score[7])
        nt2 = int(score[8])
        nt3 = int(score[9])
        nt4 = int(score[10])
        fcf1 = int(score[11])
        miba = int(score[12])
        sm1 = int(score[13])
        sj = int(score[14])
        map1 = int(score[15])
        kush = int(score[16])
        day = int(score[17])
        wjgj2 = int(score[18])
        kudi = int(score[19])
        rl1 = int(score[20])
        nt1 = int(score[21])
        bc100 = 1
    if ren.colliderect(tz1):
        if key == keys.R:
            with open('cd.txt', 'w') as f:
                print(wood, file=f)
                print(rock, file=f)
                print(guwu, file=f)
                print(mf, file=f)
                print(mut, file=f)
                print(water, file=f)
                print(zz, file=f)
                print(nt, file=f)
                print(nt2, file=f)
                print(nt3, file=f)
                print(nt4, file=f)
                print(fcf1, file=f)
                print(miba, file=f)
                print(sm1, file=f)
                print(sj, file=f)
                print(map1, file=f)
                print(kush, file=f)
                print(day, file=f)
                print(wjgj2, file=f)
                print(kudi, file=f)
                print(rl1, file=f)
                print(nt1, file=f)
            sys.exit(0)
    if key == keys.R:
        rock += 1
        kush += 1
        if wjgj2 == 0:
            print('岩石+1')
            print('矿石+1')
        if wjgj2 == 1:
            rock += 1
            kush += 1
            print('岩石+2')
            print('矿石+2')
        if wjgj2 == 2:
            rock += 2
            kush += 2
            print('岩石+3')
            print('矿石+3')  
    if key == keys.E:
        print('木材:',wood)
        print('岩石:',rock)
        print('谷物:',guwu)
        print('面粉:',mf)
        print('水:',water)
        print('种子:',zz)
        print('树苗:',sm1)
        print('矿石:',kush)
    if key == keys.C:
        with open('cd.txt', 'w') as f:
            print(wood, file=f)
            print(rock, file=f)
            print(guwu, file=f)
            print(mf, file=f)
            print(mut, file=f)
            print(water, file=f)
            print(zz, file=f)
            print(nt, file=f)
            print(nt2, file=f)
            print(nt3, file=f)
            print(nt4, file=f)
            print(fcf1, file=f)
            print(miba, file=f)
            print(sm1, file=f)
            print(sj, file=f)
            print(map1, file=f)
            print(kush, file=f)
            print(day, file=f)
            print(wjgj2, file=f)
            print(kudi, file=f)
            print(rl1, file=f)
            print(nt1, file=f)
    if key == keys.G:
        f = open('cd.txt')
        score = f.read().split()
        wood = int(score[0])
        rock = int(score[1])
        guwu = int(score[2])
        mf = int(score[3])
        mut = int(score[4])
        water = int(score[5])
        zz = int(score[6])
        nt = int(score[7])
        nt2 = int(score[8])
        nt3 = int(score[9])
        nt4 = int(score[10])
        fcf1 = int(score[11])
        miba = int(score[12])
        sm1 = int(score[13])
        sj = int(score[14])
        map1 = int(score[15])
        kush = int(score[16])
        day = int(score[17])
        wjgj2 = int(score[18])
        kudi = int(score[19])
        rl1 = int(score[20])
        nt1 = int(score[21])
    if key == keys.H:
        print('帮助:去梯子处可回家，自动保存')
def update():
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    global sj
    global wjgj2
    global tl
    global hp
    global day
    global hptl
    #变量1
    global map1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    global kush
    if keyboard.D:
        ren.x += 1
        wjct.x += 1
        ren.image = 'ren_4'
    if keyboard.D and keyboard.LCTRL:
        ren.x += 2
        wjct.x += 2
        ren.image = 'ren_4'
    if keyboard.D == False:
        ren.image = 'ren_4'
    if keyboard.A == True:
        wjct.x -= 1
        ren.image = 'ren_3'
        ren.x -= 1
    if keyboard.A == False:
        ren.image = 'ren_4'
    if keyboard.A and keyboard.LCTRL:
        wjct.x -= 2
        ren.x -= 2
        ren.image = 'ren_4'
    if keyboard.S == True:
        ren.image = 'ren_4'
        ren.y += 1
        wjct.y += 1
    if keyboard.S == False:
        ren.image = 'ren_4'
    if keyboard.S and keyboard.LCTRL:
        ren.y += 2
        wjct.y += 2
        ren.image = 'ren_4'
    if keyboard.W == True:
        ren.image = 'ren_4'
        ren.y -= 1
        wjct.y -= 1
    if keyboard.W:
        ren.image = 'ren_4'
    if keyboard.W and keyboard.LCTRL:
        ren.y -= 2
        wjct.y -= 2
        ren.image = 'ren_4'
    if keyboard.K_1:
        wpl1.image = 'wpl_1'
        wpl2.image = 'wpl_2'
        if ct.image == 'gj_sc_2':
            wjgj2 = 2
            wjct.image = 'gj_sc_2'
        if ct.image == 'gj_ct_2':
            wjgj2 = 1
            wjct.image = 'gj_ct_2'
        if ct.image == 'kong':
            wjct.image = 'kong'
            wjgj2 = 0
    if keyboard.K_2:
        wpl2.image = 'wpl_1'
        wpl1.image = 'wpl_2'
        if ct2.image == 'gj_sc_2':
            wjct.image = 'gj_sc_2'
            wjgj2 = 2
        if ct2.image == 'gj_ct_2':
            wjct.image = 'gj_ct_2'
            wjgj2 = 1
        if ct2.image == 'kong':
            wjct.image = 'kong'
            wjgj2 = 0
    if ren.x == 0 or ren.x == 854 or ren.y == 0 or ren.y == 480:
        print('触碰边界线')
    if wjct.image == 'kong':
        if wood >= 5 and rock == 20 or wjgj2 == 2:
            wjct.image = 'gj_sc_2'
            ct.image = 'gj_sc_2'
            wood -= 5
            rock -= 20
            wjgj2 = 2
        if wood >= 25 or wjgj2 == 1:
            wjct.image = 'gj_ct_2'
            ct.image = 'gj_ct_2'
            wood -= 25
            wjgj2 = 1
    if wjct.image == 'gj_ct_2':
        if wood >= 5 and rock == 20 or wjgj2 == 2:
            wjct.image = 'gj_sc_2'
            ct.image = 'gj_sc_2'
            ct2.image = 'gj_ct_2'
            wood -= 5
            rock -= 20
            wjgj2 = 2
pgzrun.go()# 运行pygame zero

