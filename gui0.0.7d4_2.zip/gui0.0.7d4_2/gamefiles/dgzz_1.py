﻿import pgzrun# 导入pygame zero
import os
import sys
curpath=os.path.abspath(os.path.dirname(__file__))
rootpath=os.path.split(curpath)[0]
sys.path.append(rootpath)

TITLE = '帝国战争0.0.7d4'#项目名
WIDTH = 854 #设置长位854
HEIGHT = 480 #设置宽为480

a = Actor('4.png')#新城池图片
a.x = 427#设置x位427
a.y = 400#设置y为400
def draw():
    screen.blit('bj2', pos=[0, 0])#设置背景
    screen.draw.text('选择',center=[427,100],fontsize = 60, color = '#C0C0C0',fontname='simsun')#显示“选择”文字
    a.draw()#a按钮图片
def on_mouse_down(pos,button):
    if a.collidepoint(pos):
        os.system("python dgzz_2.py")#a按钮,创建新城池
pgzrun.go()# 运行pygame zero

