﻿import pgzrun# 导入pygame zero
import pygame
import os
import sys
curpath=os.path.abspath(os.path.dirname(__file__))
rootpath=os.path.split(curpath)[0]
sys.path.append(rootpath)

TITLE = '帝国战争0.0.6'#项目名
WIDTH = 854 #设置长位854
HEIGHT = 480 #设置宽为480

a = Actor('1.png')#开始图片
a.x = 427#设置x位427
a.y = 400#设置y为400
def kai2():
    a.image = '1'
def draw():
    screen.blit('bj', pos=[0, 0])#设置背景
    screen.draw.text('帝国战争',center=[427,100],fontsize = 60, color = 'black',fontname='simsun')#显示“帝国战争”文字
    a.draw()#a按钮图片
def on_mouse_down(pos,button):
    if a.collidepoint(pos):
        a.image = '1'
        clock.schedule_unique(kai2, 2.0)
        os.system("python dgzz_1.py")#a按钮，打开选择界面
        a.image = '2'
def on_key_down(key):
    if key == keys.T:
        pygame.init()
        pygame.mixer.init() # 初始化混音器模块（pygame库的通用做法，每一个模块在使用时都要初始化pygame.init()为初始化所有的pygame模块，可以使用它也可以单初始化这一个模块）
        pygame.mixer.music.load("th12_02.mp3")  # 加载音乐  
        pygame.mixer.music.set_volume(0.5)# 设置音量大小0~1的浮点数
        pygame.mixer.music.play() # 播放音频
        print('bgm:春の湊に 作者:zun')
        print('原创作者兼美术：poll，,美术:LZC')
        print('2022/11/30开始制作文字版')
        print('2023/7/11开始制作gui版')
        print('2023/7/29 14:07目前最后更新')
        print('官网:https://pollresultsin.github.io/')
        print('目前版本为0.0.6(lzc版目前没有版本 文字版:java0.0.0.1放弃 C++半放弃 py文字版截止0.4.8)')
pgzrun.go()# 运行pygame zero

