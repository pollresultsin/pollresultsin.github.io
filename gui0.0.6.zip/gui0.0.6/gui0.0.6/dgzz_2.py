﻿#添加库
import pgzrun
import os
import sys
import time
#窗口
TITLE = '帝国战争0.0.6'#项目名
WIDTH = 854 #设置长位854
HEIGHT = 480 #设置宽为480
#变量0
mut = 0
fcf1 = 0
nt = 0
nt2 = 0
nt3 = 0
nt4 = 0
sj = 0
#变量1
miba = 0
zz = 0
wood = 0
rock = 0
mf = 0
guwu = 0
water = 0
sm1 = 0
#图片
ct = Actor('kong',(397,465))
ct2 = Actor('kong',(447,465))
wjct = Actor('kong',(427,240))
wpl1 = Actor('wpl_2',(397,465))
wpl2 = Actor('wpl_2',(447,465))
ys = Actor('ys_2',(820,50))
fz = Actor('fz',(427,240))
tree = Actor('tree_2',(267,60))
tree2 = Actor('tree_2',(127,40))
tree3 = Actor('tree_2',(217,80))
ren = Actor('ren_1',(427,240)) # 设置角色ren的位置
cc = Actor('cc_1',(427,240)) # 设置图片cc的位置
fcf = Actor('kong',(410,190))
sm = Actor('sj_sm_3',(145,10))
mg = Actor('cl_mg',(410,190))
he = Actor('he_1',(780,465))
he2 = Actor('he_1',(810,465))
he3 = Actor('he_1',(840,465))
he4 = Actor('he_6',(780,435))
he5 = Actor('he_6',(810,435))
he6 = Actor('he_6',(840,435))
gd = Actor('kong',(0,0))
gd2 = Actor('kong',(0,0))
gd3 = Actor('kong',(0,0))
gd4 = Actor('kong',(0,0))
#自定义
def sz1():
   gd.image = 'gd_3'
   nt = 3
def sz1_2():
   gd.image = 'gd_4'
   nt = 4
#----------
def sz2():
   gd2.image = 'gd_3'
def sz2_2():
   gd2.image = 'gd_4'
#----------
def sz3():
   gd3.image = 'gd_3'
def sz3_2():
   gd3.image = 'gd_4'
#----------
def sz4():
   gd4.image = 'gd_3'
def sz4_2():
   gd4.image = 'gd_4'
#显示
def draw():
    global sj
    if sj == 0:
        screen.blit('bj3', pos=[0, 0])#设置背景
        cc.image = 'cc_1'
        fz.image = 'fz'
    if sj == 1:
        screen.blit('bj3_2', pos=[0, 0])#设置背景
    if sj == 2:
        screen.blit('bj3_3', pos=[0, 0])#设置背景
        cc.image = 'cc_2'
        fz.image = 'fz_2'
        he.image = 'he_1'
        he2.image = 'he_1'
        he3.image = 'he_1'
        he4.image = 'he_6'
        he5.image = 'he_6'
        he6.image = 'he_6'
    tree.draw()
    tree2.draw()
    tree3.draw()
    cc.draw()
    fz.draw()
    ys.draw()
    fcf.draw()
    he.draw()
    he2.draw()
    he3.draw()
    he4.draw()
    he5.draw()
    he6.draw()
    gd.draw()
    gd2.draw()
    gd3.draw()
    gd4.draw()
    ren.draw()
    wpl1.draw()
    wpl2.draw()
    wjct.draw()
    ct.draw()
    ct2.draw()
    sm.draw()
    screen.draw.text('生命:',center=[25,10],fontsize = 20, color = 'black',fontname='simsun')#显示帮助
    screen.draw.text('e背包合成 r挖掘 h说明',center=[745,10],fontsize = 20, color = 'black',fontname='simsun')#显示帮助
#主要内容
#按键1
def on_key_down(key):
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    global sj
    #变量1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    if key == keys.R:
        if ren.colliderect(cc) or ren.colliderect(gd) or ren.colliderect(gd2) or ren.colliderect(gd3) or ren.colliderect(gd4) or ren.colliderect(tree) or ren.colliderect(tree2) or ren.colliderect(tree3) or ren.colliderect(ys):
            print('无法获得种子')
        else:
            zz += 1
            print('种子+1')
    if tree.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree.image = 'kong'
            tree.x = 0
            tree.y = 0
            sm1 += 1
            print('木材+1')
            print('树苗+1')
    if tree2.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree2.x = 0
            tree2.y = 0
            tree2.image = 'kong'
            sm1 += 1
            print('木材+1')
            print('树苗+1')
    if tree3.image == 'sz_1':
        if key == keys.R:
            wood += 1
            tree3.x = 0
            tree3.y = 0
            tree3.image = 'kong'
            sm1 += 1            
            print('木材+1')
            print('树苗+1')
    if ren.colliderect(tree) and tree.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree.image = 'sz_1'
            print('木材+3')
    if ren.colliderect(tree2) and tree2.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree2.image = 'sz_1'
            print('木材+3')
    if ren.colliderect(tree3) and tree3.image == 'tree_2':
        if key == keys.R:
            wood += 3
            tree3.image = 'sz_1'
            print('木材+3')
    if tree.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            tree.x = ren.x
            tree.y = ren.y
            print('播种成功 树苗-1')
            sm1 -= 1
            print('树苗:',sm1)
            tree.image = 'sm_1'
    if tree2.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            tree2.x = ren.x
            tree2.y = ren.y
            print('播种成功 树苗-1')
            sm1 -= 1
            print('树苗:',sm1)
            tree2.image = 'sm_1'
    if tree3.image == 'kong' and sm1 >= 1:
        if key == keys.F:
            print('播种成功 树苗-1')
            tree3.x = ren.x
            tree3.y = ren.y
            sm1 -= 1
            print('树苗:',sm1)
            tree3.image = 'sm_1'
    if ren.colliderect(tree) and tree.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree.image = 'tree_2'
    if ren.colliderect(tree2) and tree2.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree2.image = 'tree_2'
    if ren.colliderect(tree3) and tree3.image == 'sm_1' and water >= 1:
        if key == keys.R:
            water -= 1
            tree3.image = 'tree_2'
    if key == keys.E:
        print('木材:',wood)
        print('岩石:',rock)
        print('谷物:',guwu)
        print('面粉:',mf)
        print('水:',water)
        print('种子:',zz)
        print('树苗:',sm1)
        print('合成表：20石头+5木头=1石锄头 25木头=1木锄头 没有,合成一次 自动合成')
    if key == keys.H:
        print('帮助：种田，建房请去城池中心 树苗只能砍一个才能种一个,不能多砍才种,播种树苗需要浇水 吃东西回血')
        print('键位: WSAD上下左右移动 E打开背包或自动合成 R交互键（打开，交互，挖掘）G读取存档 C存档 数字1，2 切换物品栏 H帮助 F种树苗 V吃东西 `自杀')
        print('特定键位: 风车房F制作面粉B制作面包 河里M+1合成木桶')
    if key == keys.V:
        if miba >= 1:
            if sm.image == 'sj_sm_4':
                miba -= 1
                print('已使用食物')
                sm.image = 'sj_sm_3'
            if sm.image == 'sj_sm_5':
                miba -= 1
                print('已使用食物')
                sm.image = 'sj_sm_4'
            if sm.image == 'sj_sm_6':
                miba -= 1
                print('已使用食物')
                sm.image = 'sj_sm_5'
    if key == keys.BACKQUOTE:
        if sm.image == 'sj_sm_3':
            sm.image = 'sj_sm_4'
        if sm.image == 'sj_sm_4':
            sm.image = 'sj_sm_5'
        if sm.image == 'sj_sm_5':
            sm.image = 'sj_sm_6'
        if sm.image == 'sj_sm_6':
            sm.image = 'sj_sm_7'
    if fcf1 == 1:
        fcf.image = 'jz_fc_1'
        fcf.x = 410
        fcf.y = 190
        fz.image = 'kong'
    if ren.colliderect(fz):
        if nt == 0:
            if key == keys.R:
                print('是否建造农田 按F同意(水边，需要锄)')
            if key == keys.F:
                if nt == 1 or (wjct.image == 'gj_ct_1' and zz >= 17) or (wjct.image == 'gj_sc_1' and zz >= 17):
                    nt = 1
                    gd.x = 755
                    gd.y = 460
                    gd.image = 'gd_1'
                    gd2.x = 755
                    gd2.y = 475
                    gd2.image = 'gd_1'
                    gd3.x = 755
                    gd3.y = 430
                    gd3.image = 'gd_1'
                    gd4.x = 755
                    gd4.y = 445
                    gd4.image = 'gd_1'
                    zz -= 16
                    print('完成')
                    print('种子:',zz)
                else:
                    print('没有锄或者种子不够（种子>16）')
        if fcf1 == 0 and nt == 1:
            if key == keys.R:
                print('是否建造风车房 按F同意(木头 石头各50)')
            if key == keys.F:
                if fcf1 == 1 or rock >= 50 and wood >= 50:
                    fcf1 = 1
                    print('建造完毕')
                    rock -= 50
                    wood -= 50
                    print('木材:',wood)
                    print('岩石:',rock)
                    fcf.image = 'jz_fc_1'
                    fz.image = 'kong'
                else:
                    print('抱歉，您的材料不够')
                    print('木材:',wood)
                    print('岩石:',rock)
    if nt == 2:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_2'
    if nt2 == 2:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_2'
    if nt3 == 2:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_2'
    if nt4 == 2:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_2'
    #3
    if nt == 3:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_3'
    if nt2 == 3:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_3'
    if nt3 == 3:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_3'
    if nt4 == 3:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_3'
    #4
    if nt == 4:
        gd.x = 755
        gd.y = 460
        gd.image = 'gd_4'
    if nt2 == 4:
        gd2.x = 755
        gd2.y = 475
        gd2.image = 'gd_4'
    if nt3 == 4:
        gd3.x = 755
        gd3.y = 430
        gd3.image = 'gd_4'
    if nt4 == 4:
        gd4.x = 755
        gd4.y = 445
        gd4.image = 'gd_4'
    #分
    if gd.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd):
                if nt == 1:
                    nt = 2
                    gd.image = 'gd_2'
                    zz -= 10
    if gd2.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd2):
                if nt == 1:
                    nt2 = 2
                    gd2.image = 'gd_2'
                    zz -= 10
    if gd3.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd3):
                if nt == 1:
                    nt3 = 2
                    gd3.image = 'gd_2'
                    zz -= 10
    if gd4.image == 'gd_1':
        if key == keys.R:
            if ren.colliderect(gd4):
                if nt == 1:
                    nt4 = 2
                    gd4.image = 'gd_2'
                    zz -= 10
    if ren.colliderect(gd):
        if gd.image == 'gd_4' and nt == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd.image = 'gd_2'
    if ren.colliderect(gd2):
        if gd2.image == 'gd_4' and nt2 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd2.image = 'gd_2'
    if ren.colliderect(gd3):
        if gd3.image == 'gd_4' and nt3 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd3.image = 'gd_2'
    if ren.colliderect(gd4):
        if gd4.image == 'gd_4' and nt4 == 4:
            if key == keys.R:
                guwu += 2
                zz += 1
                print('谷物+2,种子+1')
                gd4.image = 'gd_2'
    if ren.colliderect(fcf):
        if key == keys.R:
            print('F制作面粉(按一次-5谷物+1面粉) B制作面包（一次一个，-10面粉）')
        if key == keys.F:
            if guwu >= 5:
                print('面粉+1')
                print('谷物-1')
                guwu -= 5
                mf += 1
            else:
                print('抱歉，您的材料不够')
                print('谷物:',guwu)
        if key == keys.B:
            if mf >= 10:
                print('面包+1')
                print('面粉-10')
                miba += 1
                mf -= 10
            else:
                print('抱歉，您的材料不够')
                print('面粉:',mf)  
    if ren.colliderect(ys):
        if key == keys.R:
            rock += 1
            print('岩石+1')
        if wjct.image == 'gj_sc_1':
            if key == keys.R:
                rock += 2
                print('岩石+2')
        if wjct.image == 'gj_ct_1':
            if key == keys.R:
                rock += 1
                print('岩石+1')
    if key == keys.C:
        with open('cd.txt', 'w') as f:
            print(wood, file=f)
            print(rock, file=f)
            print(guwu, file=f)
            print(mf, file=f)
            print(mut, file=f)
            print(water, file=f)
            print(zz, file=f)
            print(nt, file=f)
            print(nt2, file=f)
            print(nt3, file=f)
            print(nt4, file=f)
            print(fcf1, file=f)
            print(miba, file=f)
            print(sm1, file=f)
            print(sj, file=f)
    if key == keys.G:
        f = open('cd.txt')
        score = f.read().split()
        wood = int(score[0])
        rock = int(score[1])
        guwu = int(score[2])
        mf = int(score[3])
        mut = int(score[4])
        water = int(score[5])
        zz = int(score[6])
        nt = int(score[7])
        nt2 = int(score[8])
        nt3 = int(score[9])
        nt4 = int(score[10])
        fcf1 = int(score[11])
        miba = int(score[12])
        sm1 = int(score[13])
        sj = int(score[14])
    if ren.colliderect(he):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 1
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he2):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 3
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he3):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 3
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he4):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 1
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he5):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 9
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
    if ren.colliderect(he6):
        if key == keys.R:
            if mut == 1:
                if water == 0:
                    water = 9
                    print('已打水')
                else:
                    print('已打过水')
            else:
                print('请用10木头合成木桶（M+1）')
#按键2
def update():
    #变量0
    global mut
    global fcf1
    global nt
    global nt2
    global nt3
    global nt4
    #变量1
    global miba
    global wood
    global rock
    global guwu
    global mf
    global water
    global zz
    global sm1
    if gd.image == 'gd_2':
        clock.schedule_unique(sz1, 3.0)
        nt = 3
    if gd.image == 'gd_3':
        clock.schedule_unique(sz1_2, 3.0)
        nt = 4
    if gd2.image == 'gd_2':
        clock.schedule_unique(sz2, 3.0)
        nt2 = 3
    if gd2.image == 'gd_3':
        clock.schedule_unique(sz2_2, 3.0)
        nt2 = 4
    if gd3.image == 'gd_2':
        clock.schedule_unique(sz3, 3.0)
        nt3 = 3
    if gd3.image == 'gd_3':
        clock.schedule_unique(sz3_2, 3.0)
        nt3 = 4
    if gd4.image == 'gd_2':
        clock.schedule_unique(sz4, 3.0)
        nt4 = 3
    if gd4.image == 'gd_3':
        clock.schedule_unique(sz4_2, 3.0)
        nt4 = 4
    if keyboard.M:
        if keyboard.K_1:
            if mut == 0:
                if wood >= 10:
                    mut = 1
                    print('木桶+1')
                    wood -= 10
                    print('木头-10')
                else:
                    print('材料不够')
                    print('木头:',wood)
            else:
                print('已有木桶')
    if keyboard.K_1:
        wpl1.image = 'wpl_1'
        wpl2.image = 'wpl_2'
        if ct.image == 'gj_sc_1':
            wjct.image = 'gj_sc_1'
        if ct.image == 'gj_ct_1':
            wjct.image = 'gj_ct_1'
        if ct.image == 'kong':
            wjct.image = 'kong'
    if keyboard.K_2:
        wpl2.image = 'wpl_1'
        wpl1.image = 'wpl_2'
        if ct2.image == 'gj_sc_1':
            wjct.image = 'gj_sc_1'
        if ct2.image == 'gj_ct_1':
            wjct.image = 'gj_ct_1'
        if ct2.image == 'kong':
            wjct.image = 'kong'
    if keyboard.D:
        ren.x += 1
        wjct.x += 1
        ren.image = 'ren_2'
    if keyboard.D and keyboard.LCTRL:
        ren.x += 2
        wjct.x += 2
        ren.image = 'ren_2'
    if keyboard.D == False:
        ren.image = 'ren_1'
    if keyboard.A == True:
        wjct.x -= 1
        ren.image = 'ren_3'
        ren.x -= 1
    if keyboard.A == False:
        ren.image = 'ren_1'
    if keyboard.A and keyboard.LCTRL:
        wjct.x -= 2
        ren.x -= 2
        ren.image = 'ren_2'
    if keyboard.S == True:
        ren.image = 'ren_2'
        ren.y += 1
        wjct.y += 1
    if keyboard.S == False:
        ren.image = 'ren_1'
    if keyboard.S and keyboard.LCTRL:
        ren.y += 2
        wjct.y += 2
        ren.image = 'ren_2'
    if keyboard.W == True:
        ren.image = 'ren_2'
        ren.y -= 1
        wjct.y -= 1
    if keyboard.W:
        ren.image = 'ren_1'
    if keyboard.W and keyboard.LCTRL:
        ren.y -= 2
        wjct.y -= 2
        ren.image = 'ren_2'
    if ren.x == 0 or ren.x == 854 or ren.y == 0 or ren.y == 480:
        print('触碰边界线')
    if wjct.image == 'kong':
        if wood >= 25:
            wjct.image = 'gj_ct_1'
            ct.image = 'gj_ct_1'
            wood -= 25
        if wood >= 5 and rock == 20:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
            wood -= 5
            rock -= 20
    if wjct.image == 'gj_ct_1':
        if wood >= 5 and rock == 20:
            wjct.image = 'gj_sc_1'
            ct.image = 'gj_sc_1'
            ct2.image = 'gj_ct_1'
            wood -= 5
            rock -= 20
    if sm.image == 'sj_sm_7':
        input('您已死亡，回车退出')
        sys.exit(0)
pgzrun.go()# 运行pygame zero

